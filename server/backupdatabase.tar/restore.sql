--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE manualmaquinas;
--
-- Name: manualmaquinas; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE manualmaquinas WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE manualmaquinas OWNER TO postgres;

\connect manualmaquinas

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: update_categoria_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_categoria_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updatedAt = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_categoria_updated_at() OWNER TO postgres;

--
-- Name: update_maquina_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_maquina_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updatedAt = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_maquina_updated_at() OWNER TO postgres;

--
-- Name: update_problema_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_problema_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updatedAt = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_problema_updated_at() OWNER TO postgres;

--
-- Name: update_setor_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_setor_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updatedAt = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_setor_updated_at() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: categoria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categoria (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    maquina_id integer,
    createdat timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updatedat timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.categoria OWNER TO postgres;

--
-- Name: categoria_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categoria_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categoria_id_seq OWNER TO postgres;

--
-- Name: categoria_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categoria_id_seq OWNED BY public.categoria.id;


--
-- Name: maquinas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.maquinas (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    createdat timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updatedat timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.maquinas OWNER TO postgres;

--
-- Name: maquina_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.maquina_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.maquina_id_seq OWNER TO postgres;

--
-- Name: maquina_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.maquina_id_seq OWNED BY public.maquinas.id;


--
-- Name: maquina_setor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.maquina_setor (
    setor_id integer NOT NULL,
    maquina_id integer NOT NULL
);


ALTER TABLE public.maquina_setor OWNER TO postgres;

--
-- Name: problema; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.problema (
    id integer NOT NULL,
    descricao character varying(255) NOT NULL,
    categoria_id integer,
    createdat timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updatedat timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.problema OWNER TO postgres;

--
-- Name: problema_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.problema_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.problema_id_seq OWNER TO postgres;

--
-- Name: problema_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.problema_id_seq OWNED BY public.problema.id;


--
-- Name: setor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.setor (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    createdat timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updatedat timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.setor OWNER TO postgres;

--
-- Name: setor_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.setor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.setor_id_seq OWNER TO postgres;

--
-- Name: setor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.setor_id_seq OWNED BY public.setor.id;


--
-- Name: categoria id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria ALTER COLUMN id SET DEFAULT nextval('public.categoria_id_seq'::regclass);


--
-- Name: maquinas id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maquinas ALTER COLUMN id SET DEFAULT nextval('public.maquina_id_seq'::regclass);


--
-- Name: problema id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.problema ALTER COLUMN id SET DEFAULT nextval('public.problema_id_seq'::regclass);


--
-- Name: setor id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.setor ALTER COLUMN id SET DEFAULT nextval('public.setor_id_seq'::regclass);


--
-- Data for Name: categoria; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categoria (id, name, maquina_id, createdat, updatedat) FROM stdin;
\.
COPY public.categoria (id, name, maquina_id, createdat, updatedat) FROM '$$PATH$$/4889.dat';

--
-- Data for Name: maquina_setor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.maquina_setor (setor_id, maquina_id) FROM stdin;
\.
COPY public.maquina_setor (setor_id, maquina_id) FROM '$$PATH$$/4892.dat';

--
-- Data for Name: maquinas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.maquinas (id, name, createdat, updatedat) FROM stdin;
\.
COPY public.maquinas (id, name, createdat, updatedat) FROM '$$PATH$$/4887.dat';

--
-- Data for Name: problema; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.problema (id, descricao, categoria_id, createdat, updatedat) FROM stdin;
\.
COPY public.problema (id, descricao, categoria_id, createdat, updatedat) FROM '$$PATH$$/4891.dat';

--
-- Data for Name: setor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.setor (id, name, createdat, updatedat) FROM stdin;
\.
COPY public.setor (id, name, createdat, updatedat) FROM '$$PATH$$/4885.dat';

--
-- Name: categoria_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categoria_id_seq', 1, false);


--
-- Name: maquina_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.maquina_id_seq', 1, false);


--
-- Name: problema_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.problema_id_seq', 1, false);


--
-- Name: setor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.setor_id_seq', 1, true);


--
-- Name: categoria categoria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria
    ADD CONSTRAINT categoria_pkey PRIMARY KEY (id);


--
-- Name: maquinas maquina_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maquinas
    ADD CONSTRAINT maquina_pkey PRIMARY KEY (id);


--
-- Name: maquina_setor maquina_setor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maquina_setor
    ADD CONSTRAINT maquina_setor_pkey PRIMARY KEY (setor_id, maquina_id);


--
-- Name: problema problema_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.problema
    ADD CONSTRAINT problema_pkey PRIMARY KEY (id);


--
-- Name: setor setor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.setor
    ADD CONSTRAINT setor_pkey PRIMARY KEY (id);


--
-- Name: categoria categoria_update_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER categoria_update_trigger BEFORE UPDATE ON public.categoria FOR EACH ROW EXECUTE FUNCTION public.update_categoria_updated_at();


--
-- Name: maquinas maquina_update_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER maquina_update_trigger BEFORE UPDATE ON public.maquinas FOR EACH ROW EXECUTE FUNCTION public.update_maquina_updated_at();


--
-- Name: problema problema_update_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER problema_update_trigger BEFORE UPDATE ON public.problema FOR EACH ROW EXECUTE FUNCTION public.update_problema_updated_at();


--
-- Name: setor setor_update_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER setor_update_trigger BEFORE UPDATE ON public.setor FOR EACH ROW EXECUTE FUNCTION public.update_setor_updated_at();


--
-- Name: categoria categoria_maquina_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria
    ADD CONSTRAINT categoria_maquina_id_fkey FOREIGN KEY (maquina_id) REFERENCES public.maquinas(id);


--
-- Name: maquina_setor maquina_setor_maquina_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maquina_setor
    ADD CONSTRAINT maquina_setor_maquina_id_fkey FOREIGN KEY (maquina_id) REFERENCES public.maquinas(id);


--
-- Name: maquina_setor maquina_setor_setor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maquina_setor
    ADD CONSTRAINT maquina_setor_setor_id_fkey FOREIGN KEY (setor_id) REFERENCES public.setor(id);


--
-- Name: problema problema_categoria_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.problema
    ADD CONSTRAINT problema_categoria_id_fkey FOREIGN KEY (categoria_id) REFERENCES public.categoria(id);


--
-- PostgreSQL database dump complete
--

